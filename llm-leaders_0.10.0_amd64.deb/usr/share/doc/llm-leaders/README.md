# llm-leaders

A CLI that lists coding LLMs with their **OpenRouter prices** and **arena.ai WebDev Elo** score, side by side.

Example — `llm-leaders --all --max-input 1.1 --max-any-rank 30` (cheapest-input price ≤ $1.1/M, arena rank ≤ 30, across the full OpenRouter catalog):

![llm-leaders --all --max-input 1.5 --max-rank 50](assets/example.png)

## Columns

| Code | Model | Ctx | Mix | In | Out | Cache | Disc | Web | Arena | Cap | BLM | Cov | ID |
| ---: | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| OpenRouter coding benchmark rank (`#1` best) | OpenRouter model name | context window in tokens (K/M-suffixed) | usage-mix blended price per million tokens | input price per million tokens | output price per million tokens | cached-input read price per million tokens | provider discount | OpenRouter website-building benchmark rank (`#1` best) | arena.ai WebDev rank (`#1` best) | BenchmarkList capability rank (`#1` best) | BenchLM overall rank (`#1` best) | number of eligible benchmarks behind the capability score | OpenRouter model ID (copy-paste to use the model) |

Prices come live from the [OpenRouter model catalog](https://openrouter.ai/api/v1/models), then refined per model with the cheapest provider from the [endpoints API](https://openrouter.ai/api/v1/models) — the same "lowest across providers" price the OpenRouter website shows. Cheapest prices are cached for 1h at `~/.config/llm-leaders/best_prices.json`; the first `--all` run takes ~20s to fetch all providers, subsequent runs are instant.
`Mix` is the price that matches how you actually spend tokens: the weighted blend of input, output and cached-input prices at your token-usage shares. A coding agent that prompt-caches heavily pays mostly cache reads, so its effective price is neither `In` nor `Out` alone. Set the weights with `--mix input=8.1,output=0.4,cache=91.5` (percentages; they need not sum to 100 — they are normalized. The positional shorthand `8.1,0.4,91.5` works too). The mix is saved to `~/.config/llm-leaders/mix.json` and reused on later runs; the default is 3:1 input:output. A model without cache pricing charges its cached share as full input. `--sort mix` sorts by the blended price. `Mix` shows three decimals — a cache-heavy mix pushes the blend well under a cent, where two decimals would round away the differences between models. `Cache` shows the cached-input read price behind that blend (`—` when the provider reports no cache pricing).
Ranks come from Arena's official public dataset [`lmarena-ai/leaderboard-dataset`](https://huggingface.co/datasets/lmarena-ai/leaderboard-dataset) (Hugging Face, CC BY 4.0) — the `webdev` subset's `overall` category, which snapshots the [arena.ai WebDev leaderboard](https://arena.ai/leaderboard/code/webdev) daily. The leaderboard page itself rejects non-browser clients behind a Cloudflare challenge, so the dataset is the reliable machine-readable channel for the same data. Values are cached for 5h at `~/.config/llm-leaders/arena.json`. The Arena header shows the leaderboard denominator on a second line (`Arena` / `150`). Arena Elo is not shown, but still drives Model value-for-money heat and `--sort elo`.
Benchmark columns (Web = `models-website`, Code = `models-codecategories`) come from OpenRouter's frontend benchmarks endpoint, keyed by OpenRouter model ID — only canonical models are benchmarked, so tier variants (`:free` etc.) show `—`. Terminal rank cells show only the bare number to keep the table compact; Markdown keeps the `#rank` form. Their underlying scores still drive heat colors, benchmark sorting, and score filters. Cached for 5h at `~/.config/llm-leaders/benchmarks.json`. Each header shows its coverage on a second line (`Code` / `122`) — a `#1` in a sparse category is not a `#1` of 122. Note the scales differ on purpose: arena ranks a *configuration* (e.g. kimi-k3-max), the benchmarks score the *base model* — the columns sit side by side so the mismatch stays visible.

`Cap` and `Cov` are a separate second opinion from [BenchmarkList's capability index](https://benchmarklist.com/capability-index/). They are shown for every matched model, next to the arena and OpenRouter ranks. `Cap` shows only the rank; its experimental anchored capability score still drives heat colors and `--sort capability`. `Cov` shows how many eligible benchmarks support that score, so low-coverage rows need more caution. The 10.5 MB source is parsed as a stream and only scored rows are retained. Matches use the normalized provider/model ID; a tail-ID match also requires compatible model names. Values are cached for 5h at `~/.config/llm-leaders/capability.json`. `--no-bench` hides them with the other benchmark columns.

`BLM` is an independent overall rank from [BenchLM](https://benchlm.ai/models), covering its scored primary and sibling models. BenchLM provides explicit ranks for primary models. Scored siblings use a derived competition rank: their score is placed among the ranked primary-model scores, so tied scores share a rank. `--sort benchlm` follows that displayed rank, then score as a tiebreak. Matching first uses the OpenRouter model tail ID against the BenchLM slug, then the normalized display name. The endpoint's Next.js build ID is discovered from the models page; parsed data is cached for 5h at `~/.config/llm-leaders/benchlm.json`. `--no-bench` hides the column.

Cache TTLs at a glance: prices 5-min catalog / 1h endpoints (15-min discount check), arena 5h, benchmarks 5h, capability 5h, BenchLM 5h. `--refresh` busts caches selectively. The usage mix (`mix.json`) persists until changed.

Non-coding models (image/video generators, music/lyric/audio/speech TTS/STT, embedders, rerankers) are dropped by default — `--include-non-coding` shows them. The signal is OpenRouter's own `architecture.output_modalities` from the v1 API: a coding model outputs text only, while image/video/audio/speech/transcription/embeddings/rerank outputs mark a non-coding model. It is authoritative and catches models a token list would miss (e.g. Lyria, which has `quick_start_example_type: null` but outputs `text+audio`). There is no hardcoded token list: a substring heuristic decays against the catalog and silently drops coding models whose names happen to contain a token (e.g. "Thinking Machines: Inkling", which outputs text).

Batch tier variants (`:batch` — the batch-discounted endpoint of a model, priced separately but ranked as the same model) are dropped by default so each model appears once — `--include-batch` shows their rows too.

The terminal table uses heat scales, all computed over the rows actually displayed so they stay meaningful under any filter combination:

- **Model** — hidden-Elo value-for-money heat: Elo odds (`10^(Elo/400)` — each +400 Elo counts as 10× quality) per dollar of blended price (input weighted 3 : output 1, log-scaled). Green = best quality-per-dollar in view, red = worst. Free models with a known Elo render **bold pure green** — unbeatable per dollar.
- **Ctx** — green = largest context window in view, scaling through yellow to red = smallest.
- **Arena** — green = best rank in view, scaling through yellow to red = worst.
- **Web / Code / bench columns / Cap / BLM** — green = highest score in view, same ramp as Elo.
- **Mix $/M / In $/M / Out $/M / Cache $/M** — green = cheapest in view, scaling through yellow to red = priciest.

Columns with no spread (e.g. a single-row result) are left uncolored.

## Usage

```sh
# render the table (sorted by OpenRouter Code rank, asc — best on top; the
# Code Rank column leads, Arena Rank sits near the end)
llm-leaders

# markdown table for pasting into docs/PRs
llm-leaders --markdown

# sort by arena rank (asc), arena elo (desc), input price (asc), output price
# (asc), mix price (asc), name (asc), context window (desc), or a benchmark
# score (desc): web-score, code-score, bench (the --bench column when set,
# else Web Rank), or capability (BenchmarkList). benchlm sorts by its
# displayed rank.
llm-leaders --sort arena-rank
llm-leaders --sort elo
llm-leaders --sort input
llm-leaders --sort output
llm-leaders --sort mix
llm-leaders --sort name
llm-leaders --sort ctx
llm-leaders --sort web-score
llm-leaders --sort capability
llm-leaders --sort benchlm

# keep only models cheaper than $1/M input (free models always pass;
# models with no known price are dropped)
llm-leaders --max-input 1

# keep only models with output price at most $1/M
llm-leaders --max-output 1

# set the token-usage mix behind the Mix column (agent profile: 8.1% input,
# 0.4% output, 91.5% cached input) — saved and reused on later runs
llm-leaders --mix input=8.1,output=0.4,cache=91.5

# keep only models whose Mix (blended) price is at most $0.5/M
llm-leaders --max-mix 0.5

# keep only models ranked in the arena top 20 (models with no arena score
# are dropped when this filter is set)
llm-leaders --max-rank 20

# keep only models scoring at least 1300 on the active benchmark column
# (--bench's category when set, else OR Web; models without a score are dropped)
llm-leaders --min-score 1300

# keep only models scoring at least 1300 on OR Web / Code specifically
llm-leaders --min-or-web 1300
llm-leaders --min-code 1300

# keep only models ranked in the OR Web / Code top 20 (models without a
# score in that category are dropped when this filter is set)
llm-leaders --max-or-web-rank 20
llm-leaders --max-code-rank 20

# keep models ranking in the top 20 of ANY rank column (OR): a model is kept
# if it matches even one of Arena, Web, Code, Cap, BLM. One value = same
# threshold for all five; five values = per-column thresholds (arena web code
# cap benchlm). The old three- and four-value forms still work and leave later
# columns unfiltered.
llm-leaders --max-any-rank 20
llm-leaders --max-any-rank 20 10 15 40 60

# keep only free models / only discounted models
llm-leaders --free
llm-leaders --discounted

# fuzzy search by name or ID (subsequence match, multi-word AND)
llm-leaders --search "glm"
llm-leaders --search "kimi k3"        # both words must match
llm-leaders --all --search "opus"     # search across the whole catalog

# browse the entire OpenRouter catalog (~400 models) instead of your
# curated list — combines with the filters above
llm-leaders --all --max-rank 10 --max-input 1

# combine filters
llm-leaders --max-input 1 --max-rank 20

# benchmark columns: add any of the 27 categories as an extra column
# (short form accepted — "uicomponent" resolves to "models-uicomponent")
llm-leaders --bench agents-fullstack
llm-leaders --bench uicomponent

# list all 27 benchmark categories with model counts
llm-leaders --list-bench

# drop the default benchmark columns (OR Web, Code) for the 7-column layout
llm-leaders --no-bench

# show the full catalog including non-coding models (image, video,
# music, TTS, embedders, rerankers). Default: drop them.
llm-leaders --include-non-coding

# show :batch tier variants (the batch-discounted endpoint of a model,
# ranked as the same model). Default: hide them so each model appears once.
llm-leaders --include-batch

# force-refresh caches: prices (catalog + endpoints), ranks (arena +
# benchmarks + capability + BenchLM), or all. Bare --refresh means all.
llm-leaders --refresh prices
llm-leaders --refresh ranks
llm-leaders --refresh

# manage the curated model list
llm-leaders add                    # interactive picker over the OpenRouter catalog
llm-leaders add z-ai/glm-5.2       # add one or more IDs directly (validated against the catalog)
llm-leaders remove                 # interactive multi-select over your current list
llm-leaders remove z-ai/glm-5.2    # remove by ID
llm-leaders list                   # print the current list
```

## The curated list

The curated list is loaded from:
1. `./models.txt` in the current working directory (if present), or
2. `~/.config/llm-leaders/models.txt` (global user config).

If neither file exists, `llm-leaders` automatically falls back to showing all models (`--all`).
Running `llm-leaders add` creates and updates `~/.config/llm-leaders/models.txt` automatically (or `./models.txt` if run inside the project repo). One OpenRouter model ID per line (`#` comments allowed).

## Build

```sh
cargo build --release
# binary at target/release/llm-leaders
```

## Packaging & Installation

A tagged push (`git tag v0.1.0 && git push --tags`) triggers [.github/workflows/release.yml](.github/workflows/release.yml), which:

1. builds the release binary and UPX-compresses it,
2. packs `llm-leaders-<ver>-x86_64-unknown-linux-gnu.tar.gz` (binary + LICENSE),
3. builds a Debian / Ubuntu `.deb` package (`llm-leaders_<ver>_amd64.deb`),
4. lints the Arch package plan with `namcap`,
5. publishes a GitHub Release with both the tarball and `.deb` package, and
6. updates the `llm-leaders-bin` AUR package — [packaging/arch/PKGBUILD](packaging/arch/PKGBUILD) is the canonical source; [packaging/arch/publish-aur.sh](packaging/arch/publish-aur.sh) clones AUR, injects the tarball's real `b2sum`, regenerates `.SRCINFO`, and pushes over SSH.

### Arch Linux (AUR)

Install from AUR:
```sh
yay -S llm-leaders-bin
```

### Ubuntu / Debian (APT Repository)

Install and update directly using `apt`:

```sh
# 1. Add repository GPG key
sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://mohamadkhani.github.io/llm-leaders/KEY.gpg | sudo gpg --dearmor --yes -o /etc/apt/keyrings/llm-leaders.gpg

# 2. Add repository source
echo "deb [signed-by=/etc/apt/keyrings/llm-leaders.gpg] https://mohamadkhani.github.io/llm-leaders/ ./" | sudo tee /etc/apt/sources.list.d/llm-leaders.list

# 3. Update and install
sudo apt update
sudo apt install llm-leaders
```

To update `llm-leaders` in the future:
```sh
sudo apt update && sudo apt upgrade
```

#### Manual `.deb` download
Alternatively, download the `.deb` file directly from [GitHub Releases](https://github.com/mohamadkhani/llm-leaders/releases):
```sh
sudo apt install ./llm-leaders_<version>_amd64.deb
```

To build the `.deb` package locally:
```sh
cargo build --release
packaging/debian/build-deb.sh <version>
```
